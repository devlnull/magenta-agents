# Order total rules

All amounts are whole rials (int).

1. Item subtotal = sum of unit price x quantity.
2. Discount codes: at most one percentage code and one fixed code. Apply the percentage code first, then the
   fixed code. The discount never makes the subtotal negative.
3. Rounding: round each discount amount half up to a whole rial.
4. VAT is 10% of the subtotal after the discounts, rounded half up.
5. Shipping is 50,000 rials. It is free when the subtotal after the discounts is at least 1,000,000 rials.
6. Total = subtotal after discounts + VAT + shipping.
