CODES = {"OFF10": ("percent", 10), "OFF15": ("percent", 15), "MINUS50K": ("fixed", 50000), "MINUS1M": ("fixed", 1000000)}

def discounts(codes):
    return [CODES[c] for c in codes]
