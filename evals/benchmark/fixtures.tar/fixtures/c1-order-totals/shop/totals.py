from .codes import discounts

SHIPPING = 50000
FREE_SHIPPING_FROM = 1000000

def subtotal(items):
    return sum(price * qty for price, qty in items)

def after_discounts(amount, codes):
    for kind, value in discounts(codes):
        if kind == "fixed":
            amount -= value
        else:
            amount -= amount * value // 100
    return amount

def total(items, codes=()):
    raw = subtotal(items)
    net = after_discounts(raw, codes)
    vat = raw * 10 // 100
    shipping = 0 if raw >= FREE_SHIPPING_FROM else SHIPPING
    return net + vat + shipping
