from shop.totals import total

def test_no_codes_small_order():
    assert total([(100000, 2)]) == 200000 + 20000 + 50000
