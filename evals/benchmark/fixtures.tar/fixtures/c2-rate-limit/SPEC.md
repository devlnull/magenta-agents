# Login rate limit

Implement `shop/ratelimit.py`:

- `RateLimiter(capacity, refill_per_second, clock=time.monotonic)`: a token bucket for each key.
  A new key starts full. Tokens refill continuously, never above the capacity.
- `allow(key, cost=1) -> bool`: True and take the tokens when the key has at least `cost` tokens; else False
  and take nothing.
- `retry_after(key, cost=1) -> float`: seconds until `allow(key, cost)` can be True (0.0 when it is True now).

Use it in `shop/auth.py` `login(user, ip, password)`: at most 5 tries in a minute for each user and 5 for each
IP (capacity 5, refill 5/60 per second). A refused try raises `TooManyTries(retry_after)` and does not check
the password; it takes no token from the other key either. The behavior of a correct or wrong password stays
the same. Keep the two limiters as module-level objects in `shop/auth.py`.
