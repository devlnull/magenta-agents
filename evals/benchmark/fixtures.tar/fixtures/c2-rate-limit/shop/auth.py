PASSWORDS = {"ann": "secret"}

class WrongPassword(Exception):
    pass

def login(user, ip, password):
    if PASSWORDS.get(user) != password:
        raise WrongPassword(user)
    return {"user": user}
