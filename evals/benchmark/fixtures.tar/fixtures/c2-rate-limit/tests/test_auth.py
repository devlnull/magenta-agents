import pytest
from shop.auth import login, WrongPassword

def test_login_ok():
    assert login("ann", "1.1.1.1", "secret") == {"user": "ann"}

def test_wrong_password():
    with pytest.raises(WrongPassword):
        login("ann", "1.1.1.2", "bad")
