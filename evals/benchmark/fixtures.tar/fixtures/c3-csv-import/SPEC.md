# Product import

Implement `import_products(csv_text) -> Report` in `shop/importer.py`.

- The first line is the header. Required columns: `sku`, `name`, `price`. Other columns are ignored. The order
  of the columns can change. A missing required column: raise `ValueError` with the name of the column.
- Strip the spaces around each value. Skip empty lines.
- `price` is a positive integer (rials). `sku` and `name` are not empty.
- A row with an error is not imported. The error has the line number (the header is line 1) and a message.
- A duplicate `sku`: keep the first row, report the later rows as errors.
- `Report` has: `products` (list of dicts with `sku`, `name`, `price` as int, in the order of the file),
  `errors` (list of `(line_number, message)`), and `imported` (the number of products).
