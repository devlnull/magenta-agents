from dataclasses import dataclass, field

@dataclass
class Report:
    products: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    imported: int = 0

def import_products(csv_text):
    raise NotImplementedError
