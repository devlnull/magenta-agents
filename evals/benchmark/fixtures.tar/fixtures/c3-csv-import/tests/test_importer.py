from shop.importer import Report

def test_report_defaults():
    assert Report().imported == 0
