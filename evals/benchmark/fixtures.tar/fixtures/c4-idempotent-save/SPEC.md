# Save an order

`save_order(cart_id, request_id)` in `shop/orders.py` creates an order for a cart and returns it.

Problem: when the user submits two times, the shop creates two orders. New rules:

1. The same `request_id` returns the same order (no new order), also for another cart_id: the first result wins.
2. When the cart already has an unpaid order, return that order (no new order).
3. When the last order of the cart is paid, a new submit creates a new order.
4. `pay(order_id)` marks an order paid. Paying twice is an error (`AlreadyPaid`).
5. Keep the shape of an order: `{"id", "cart_id", "status"}` with status "unpaid" or "paid".
