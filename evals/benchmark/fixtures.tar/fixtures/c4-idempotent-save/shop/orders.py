from .repo import Repo

REPO = Repo()

def save_order(cart_id, request_id):
    return REPO.add(cart_id)

def pay(order_id):
    REPO.orders[order_id]["status"] = "paid"
