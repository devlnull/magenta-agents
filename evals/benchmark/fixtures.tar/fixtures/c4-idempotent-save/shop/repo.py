import itertools

class Repo:
    def __init__(self):
        self.orders = {}
        self._ids = itertools.count(1)

    def add(self, cart_id):
        order = {"id": next(self._ids), "cart_id": cart_id, "status": "unpaid"}
        self.orders[order["id"]] = order
        return order
