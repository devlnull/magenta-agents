from shop import orders

def test_save_returns_unpaid_order():
    order = orders.save_order("cart-1", "r-1")
    assert order["cart_id"] == "cart-1" and order["status"] == "unpaid"
