def to_rials(amount):
    """Convert a float amount to whole rials."""
    return int(amount)
