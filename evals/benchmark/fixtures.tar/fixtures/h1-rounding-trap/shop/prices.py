from .money import to_rials

def price_with_vat(net):
    """Net price plus 9% VAT, in whole rials."""
    return to_rials(net * 1.09)
