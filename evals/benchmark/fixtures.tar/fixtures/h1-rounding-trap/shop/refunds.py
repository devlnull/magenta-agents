from .money import to_rials

def refund_amount(paid, used_fraction):
    """The refund for an unused part of a service. By the refund policy (legal), a refund is ALWAYS rounded
    DOWN to a whole rial, never up."""
    return to_rials(paid * (1 - used_fraction))
