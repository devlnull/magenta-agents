from shop.prices import price_with_vat
def test_vat_whole():
    assert price_with_vat(100) == 109
