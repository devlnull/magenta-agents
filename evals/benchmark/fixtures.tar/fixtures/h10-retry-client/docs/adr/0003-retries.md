# ADR-0003: Retries of remote calls

Status: Accepted

- Retry only idempotent calls: GET, PUT, DELETE. Never retry POST: a payment can be charged two times.
- At most 3 tries in total. Wait 0.1 s, then 0.2 s between the tries.
- Retry only on a timeout or a status 502, 503, or 504. Never retry a 4xx status.
