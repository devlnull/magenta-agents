class Timeout(Exception):
    pass

def call(transport, method, url, sleep=None):
    """Send one request with transport(method, url) -> status code. Return the status."""
    return transport(method, url)
