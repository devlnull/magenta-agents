from shop.http import call
def test_ok():
    assert call(lambda m, u: 200, "GET", "/x") == 200
