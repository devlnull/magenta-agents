def find_duplicates(names):
    """Return the names that occur more than one time. Compare without case and without spaces at the ends.
    Return each duplicate one time, in the form of its FIRST occurrence (as written, stripped), in the order of
    the second occurrence in the list."""
    result = []
    seen_keys = []
    for i, name in enumerate(names):
        key = name.strip().lower()
        for j in range(i):
            if names[j].strip().lower() == key and key not in seen_keys:
                result.append(names[j].strip())
                seen_keys.append(key)
                break
    return result
