from shop.catalog import find_duplicates
def test_simple():
    assert find_duplicates(["a", "b", "A"]) == ["a"]
