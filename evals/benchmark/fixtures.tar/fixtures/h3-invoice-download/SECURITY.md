# Security rules of the shop

- A user reads only their own data. An admin (`user["role"] == "admin"`) reads all data.
- A file name from a request is never used as a path as it is. Only names that match `[A-Za-z0-9_-]+\.pdf`
  are valid; for other names raise `ValueError`.
- A refused access raises `PermissionError`. A missing file raises `FileNotFoundError`.
