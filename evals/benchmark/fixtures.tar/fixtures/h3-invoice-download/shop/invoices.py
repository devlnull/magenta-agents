from pathlib import Path

INVOICE_DIR = Path(__file__).parent / "data" / "invoices"
OWNERS = {"inv-1001.pdf": "ann", "inv-1002.pdf": "bob"}

def list_invoices(user):
    return sorted(n for n, owner in OWNERS.items() if owner == user["name"] or user.get("role") == "admin")
