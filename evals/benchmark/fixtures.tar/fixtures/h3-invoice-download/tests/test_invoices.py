from shop.invoices import list_invoices
def test_list_own():
    assert list_invoices({"name": "ann"}) == ["inv-1001.pdf"]
