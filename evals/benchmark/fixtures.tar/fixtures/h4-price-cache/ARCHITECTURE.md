# Architecture rules

- `shop/db.py` is the only module that talks to the database.
- A price can change at any time with `set_price`. After `set_price` returns, no read may return the old price.
- `db.QUERIES` counts the database reads. Tests use it.
