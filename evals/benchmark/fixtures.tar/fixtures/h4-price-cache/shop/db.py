QUERIES = 0
_PRICES = {"pen": 1000, "cup": 5000}

def read_price(sku):
    global QUERIES
    QUERIES += 1
    return _PRICES[sku]

def write_price(sku, price):
    _PRICES[sku] = price
