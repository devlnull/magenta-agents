from . import db

def get_price(sku):
    return db.read_price(sku)

def set_price(sku, price):
    db.write_price(sku, price)
