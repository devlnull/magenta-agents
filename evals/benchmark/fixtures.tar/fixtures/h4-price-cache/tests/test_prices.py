from shop.prices import get_price
def test_get():
    assert get_price("pen") == 1000
