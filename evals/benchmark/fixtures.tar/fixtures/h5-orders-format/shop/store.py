import json

def save_orders(path, orders):
    """Write orders as JSON lines: one object for each line, with the keys id and total."""
    with open(path, "w", encoding="utf-8") as f:
        for o in orders:
            f.write(json.dumps({"id": o["id"], "total": o["total"]}) + "\n")

def load_orders(path):
    """Read the orders. Files of all earlier versions must stay readable: customers keep old exports."""
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]
