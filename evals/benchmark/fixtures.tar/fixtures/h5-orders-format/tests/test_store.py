from shop.store import save_orders, load_orders
def test_roundtrip(tmp_path):
    p = tmp_path / "o.jsonl"
    save_orders(p, [{"id": 1, "total": 10}])
    assert load_orders(p)[0]["total"] == 10
