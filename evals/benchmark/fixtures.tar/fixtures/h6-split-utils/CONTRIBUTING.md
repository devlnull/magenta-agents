# Contributing

- `shop.utils` is a public API: other teams import from it. A change must keep every name that it exports today.
