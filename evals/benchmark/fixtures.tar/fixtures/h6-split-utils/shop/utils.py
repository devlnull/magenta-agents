import re

def format_rials(amount):
    return f"{amount:,} rials"

def parse_rials(text):
    return int(text.replace(",", "").replace("rials", "").strip())

def slug(text):
    return "-".join(re.findall(r"[a-z0-9]+", text.lower()))

def initials(name):
    return "".join(p[0].upper() for p in name.split() if p)
