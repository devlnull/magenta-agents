from shop.utils import format_rials
def test_format():
    assert format_rials(1500) == "1,500 rials"
