# Personal data

- An export for a user that is not an admin never shows a full email or phone number. Mask an email as the first
  letter, `***`, and the domain (`a***@example.com`). Mask a phone number: all digits except the last 2 become `*`.
- An admin (`viewer["role"] == "admin"`) sees the full values.
- A deleted user (`deleted: True`) is never exported.
