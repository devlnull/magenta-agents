USERS = [
    {"id": 1, "name": "Ann", "email": "ann@example.com", "phone": "09121234567", "deleted": False},
    {"id": 2, "name": "Bob", "email": "bob@shop.ir", "phone": "09351112233", "deleted": True},
    {"id": 3, "name": "Cyd", "email": "c@x.io", "phone": "021555", "deleted": False},
]

def get_user(user_id):
    return next(u for u in USERS if u["id"] == user_id)
