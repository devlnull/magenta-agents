from shop.users import get_user
def test_get():
    assert get_user(1)["name"] == "Ann"
