# API rules

- Never rename or remove a field of a response: mobile apps of old versions read them.
- Money fields are integers in rials, and their names end with `_rials`.
- Field names are snake_case.
