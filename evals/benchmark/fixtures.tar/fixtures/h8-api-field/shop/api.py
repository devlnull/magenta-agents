def order_response(order):
    """The JSON body of GET /orders/<id>."""
    return {
        "id": order["id"],
        "status": order["status"],
        "total_rials": order["total"],
    }
