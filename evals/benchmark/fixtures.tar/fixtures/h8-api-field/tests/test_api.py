from shop.api import order_response
def test_fields():
    assert order_response({"id": 1, "status": "paid", "total": 100})["total_rials"] == 100
