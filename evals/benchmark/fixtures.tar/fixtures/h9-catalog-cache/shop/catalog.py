import json
from pathlib import Path

CATALOG = Path(__file__).parent / "catalog.json"

def load_catalog(path=CATALOG):
    """Return the products of the catalog file. The merchandising team edits the file while the shop runs:
    a change of the file must be visible at the next call."""
    return json.loads(Path(path).read_text(encoding="utf-8"))
