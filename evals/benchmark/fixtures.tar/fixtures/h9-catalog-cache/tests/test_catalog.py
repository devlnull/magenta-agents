from shop.catalog import load_catalog
def test_load():
    assert load_catalog()[0]["sku"] == "A"
