from shop.totals import total
def test_small(): assert total([(100000, 2)]) == 270000
def test_free_shipping_after_discount_only():
    # 1,050,000 - 10% = 945,000 -> shipping is not free
    assert total([(1050000, 1)], ["OFF10"]) == 945000 + 94500 + 50000
def test_free_shipping(): assert total([(1200000, 1)]) == 1200000 + 120000
def test_vat_after_discount(): assert total([(500000, 1)], ["MINUS50K"]) == 450000 + 45000 + 50000
def test_percent_then_fixed_any_order():
    a = total([(1000000, 1)], ["MINUS50K", "OFF10"]); b = total([(1000000, 1)], ["OFF10", "MINUS50K"])
    assert a == b == 850000 + 85000 + 50000
def test_half_up_discount(): assert total([(1005, 1)], ["OFF15"]) == 854 + 85 + 50000
def test_half_up_vat(): assert total([(1005, 1)]) == 1005 + 101 + 50000
def test_not_negative(): assert total([(300000, 1)], ["MINUS1M"]) == 0 + 0 + 50000
