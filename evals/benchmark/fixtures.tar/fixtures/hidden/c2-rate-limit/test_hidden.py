import importlib, pytest
from shop.ratelimit import RateLimiter
class Clock:
    def __init__(self): self.t = 1000.0
    def __call__(self): return self.t
def test_bucket_basics():
    c = Clock(); r = RateLimiter(3, 1.0, clock=c)
    assert [r.allow("k") for _ in range(4)] == [True, True, True, False]
    assert abs(r.retry_after("k") - 1.0) < 1e-6
    c.t += 1.0; assert r.allow("k") and not r.allow("k")
def test_keys_are_separate():
    c = Clock(); r = RateLimiter(1, 1.0, clock=c)
    assert r.allow("a") and r.allow("b") and not r.allow("a")
def test_never_above_capacity():
    c = Clock(); r = RateLimiter(2, 1.0, clock=c); c.t += 100
    assert [r.allow("k") for _ in range(3)] == [True, True, False]
def test_cost_and_no_partial_take():
    c = Clock(); r = RateLimiter(5, 1.0, clock=c)
    assert r.allow("k", 4) and not r.allow("k", 2) and r.allow("k", 1)
def test_retry_after_zero(): assert RateLimiter(1, 1.0, clock=Clock()).retry_after("x") == 0.0
def _auth():
    import shop.auth as auth; return importlib.reload(auth)
def test_login_limit_per_ip():
    auth = _auth()
    for i in range(5):
        with pytest.raises(auth.WrongPassword): auth.login(f"u{i}", "9.9.9.9", "bad")
    with pytest.raises(auth.TooManyTries): auth.login("ann", "9.9.9.9", "secret")
def test_login_limit_per_user():
    auth = _auth()
    for i in range(5):
        with pytest.raises(auth.WrongPassword): auth.login("ann", f"8.8.8.{i}", "bad")
    with pytest.raises(auth.TooManyTries): auth.login("ann", "7.7.7.7", "secret")
def test_login_ok_still_works():
    auth = _auth(); assert auth.login("ann", "6.6.6.6", "secret") == {"user": "ann"}
def test_too_many_tries_has_retry_after():
    auth = _auth()
    for i in range(5):
        with pytest.raises(auth.WrongPassword): auth.login("bob", "5.5.5.5", "x")
    with pytest.raises(auth.TooManyTries) as e: auth.login("bob", "5.5.5.5", "x")
    assert e.value.args and float(e.value.args[0]) > 0
