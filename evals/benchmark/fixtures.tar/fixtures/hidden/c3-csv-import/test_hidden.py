import pytest
from shop.importer import import_products
def test_basic():
    r = import_products("sku,name,price\nA1,Pen,1000\nB2,Book,25000\n")
    assert r.products == [{"sku": "A1", "name": "Pen", "price": 1000}, {"sku": "B2", "name": "Book", "price": 25000}]
    assert r.imported == 2 and r.errors == []
def test_column_order_and_extra():
    r = import_products("price,color,sku,name\n500,red,X,Cap\n")
    assert r.products == [{"sku": "X", "name": "Cap", "price": 500}]
def test_missing_column():
    with pytest.raises(ValueError, match="price"): import_products("sku,name\nA,B\n")
def test_strip_and_empty_lines():
    r = import_products("sku , name , price\n  A1 ,  Pen , 1000 \n\n")
    assert r.products == [{"sku": "A1", "name": "Pen", "price": 1000}]
def test_bad_rows_have_line_numbers():
    r = import_products("sku,name,price\nA,Pen,abc\nB,,100\nC,Cup,-5\nD,Mug,0\nE,Ok,7\n")
    assert [line for line, _ in r.errors] == [2, 3, 4, 5]
    assert r.imported == 1 and r.products[0]["sku"] == "E"
def test_duplicate_sku():
    r = import_products("sku,name,price\nA,One,1\nA,Two,2\n")
    assert r.products == [{"sku": "A", "name": "One", "price": 1}] and [l for l, _ in r.errors] == [3]
def test_line_numbers_count_empty_lines():
    r = import_products("sku,name,price\n\nA,Pen,x\n")
    assert [l for l, _ in r.errors] == [3]
