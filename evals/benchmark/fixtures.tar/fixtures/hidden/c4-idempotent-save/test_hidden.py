import importlib, pytest
def fresh():
    import shop.repo, shop.orders
    importlib.reload(shop.repo); return importlib.reload(shop.orders)
def test_same_request_same_order():
    o = fresh(); a = o.save_order("c1", "r1"); b = o.save_order("c1", "r1"); assert a["id"] == b["id"]
def test_same_request_other_cart():
    o = fresh(); a = o.save_order("c1", "r1"); b = o.save_order("c2", "r1"); assert b["id"] == a["id"]
def test_unpaid_order_reused():
    o = fresh(); a = o.save_order("c1", "r1"); b = o.save_order("c1", "r2"); assert a["id"] == b["id"]
def test_paid_then_new():
    o = fresh(); a = o.save_order("c1", "r1"); o.pay(a["id"]); b = o.save_order("c1", "r2")
    assert b["id"] != a["id"] and b["status"] == "unpaid"
def test_pay_twice():
    o = fresh(); a = o.save_order("c1", "r1"); o.pay(a["id"])
    with pytest.raises(o.AlreadyPaid): o.pay(a["id"])
def test_shape():
    o = fresh(); a = o.save_order("c9", "r9"); assert set(a) == {"id", "cart_id", "status"}
def test_carts_are_separate():
    o = fresh(); a = o.save_order("c1", "r1"); b = o.save_order("c2", "r2"); assert a["id"] != b["id"]
