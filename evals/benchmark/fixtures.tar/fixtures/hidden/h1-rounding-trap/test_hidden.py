from shop.prices import price_with_vat
from shop.refunds import refund_amount
def test_vat_half_up(): assert price_with_vat(1005) == 1095   # 1095.45 -> 1095
def test_vat_up(): assert price_with_vat(1006) == 1097       # 1096.54 -> 1097
def test_vat_float_noise(): assert price_with_vat(500) == 545
def test_refund_rounds_down(): assert refund_amount(1000, 0.3333) == 666   # 666.7 -> 666
def test_refund_rounds_down_2(): assert refund_amount(999, 0.5) == 499     # 499.5 -> 499
def test_refund_whole(): assert refund_amount(1000, 0.5) == 500
