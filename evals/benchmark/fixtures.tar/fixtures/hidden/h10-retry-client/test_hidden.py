import pytest
from shop.http import call, Timeout
def seq(*items):
    it = iter(items); log = []
    def t(m, u):
        log.append(m); x = next(it)
        if isinstance(x, Exception): raise x
        return x
    return t, log
def test_get_retries_503():
    t, log = seq(503, 503, 200); waits = []
    assert call(t, "GET", "/x", sleep=waits.append) == 200 and len(log) == 3 and waits == [0.1, 0.2]
def test_timeout_retried():
    t, log = seq(Timeout(), 200); assert call(t, "PUT", "/x", sleep=lambda s: None) == 200 and len(log) == 2
def test_max_three():
    t, log = seq(503, 503, 503, 200); assert call(t, "GET", "/x", sleep=lambda s: None) == 503 and len(log) == 3
def test_post_never_retried():
    t, log = seq(503, 200); assert call(t, "POST", "/pay", sleep=lambda s: None) == 503 and len(log) == 1
def test_4xx_not_retried():
    t, log = seq(404, 200); assert call(t, "GET", "/x", sleep=lambda s: None) == 404 and len(log) == 1
def test_timeout_after_last_try():
    t, log = seq(Timeout(), Timeout(), Timeout())
    with pytest.raises(Timeout): call(t, "DELETE", "/x", sleep=lambda s: None)
