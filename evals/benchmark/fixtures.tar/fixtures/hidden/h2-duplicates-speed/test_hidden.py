import time
from shop.catalog import find_duplicates
def test_form_of_first(): assert find_duplicates([" Pen ", "cup", "PEN", "pen"]) == ["Pen"]
def test_order_of_second():
    assert find_duplicates(["b", "a", "A", "B"]) == ["a", "b"]
def test_three_times_once(): assert find_duplicates(["x", "X", "x "]) == ["x"]
def test_none(): assert find_duplicates(["a", "b"]) == []
def test_speed():
    names = [f"item{i}" for i in range(60000)] + [f"ITEM{i} " for i in range(0, 60000, 3)]
    t = time.perf_counter(); r = find_duplicates(names); dt = time.perf_counter() - t
    assert len(r) == 20000 and r[0] == "item0" and dt < 1.0
