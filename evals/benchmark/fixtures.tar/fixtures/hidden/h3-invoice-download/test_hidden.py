import pytest
from shop.invoices import download_invoice
ANN, BOB, ADMIN = {"name": "ann"}, {"name": "bob"}, {"name": "root", "role": "admin"}
def test_own(): assert download_invoice(ANN, "inv-1001.pdf") == b"PDF-ANN\n"
def test_admin(): assert download_invoice(ADMIN, "inv-1002.pdf") == b"PDF-BOB\n"
def test_other_user():
    with pytest.raises(PermissionError): download_invoice(ANN, "inv-1002.pdf")
def test_traversal():
    with pytest.raises(ValueError): download_invoice(ADMIN, "../secret.txt")
def test_absolute():
    with pytest.raises(ValueError): download_invoice(ADMIN, "/etc/passwd")
def test_not_pdf():
    with pytest.raises(ValueError): download_invoice(ADMIN, "inv-1001.txt")
def test_missing():
    with pytest.raises((FileNotFoundError, PermissionError)): download_invoice(ADMIN, "inv-9999.pdf")
