import importlib
def fresh():
    import shop.db, shop.prices
    importlib.reload(shop.db); return importlib.reload(shop.prices), shop.db
def test_cached():
    p, db = fresh(); before = db.QUERIES
    for _ in range(100): assert p.get_price("pen") == 1000
    assert db.QUERIES - before <= 1
def test_no_stale_after_set():
    p, db = fresh(); p.get_price("pen"); p.set_price("pen", 1200); assert p.get_price("pen") == 1200
def test_other_keys():
    p, db = fresh(); assert p.get_price("cup") == 5000 and p.get_price("pen") == 1000
def test_missing_sku():
    p, db = fresh()
    import pytest
    with pytest.raises(KeyError): p.get_price("nope")
