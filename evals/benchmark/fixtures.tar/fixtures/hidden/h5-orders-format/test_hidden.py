from shop.store import save_orders, load_orders
def test_new_roundtrip(tmp_path):
    p = tmp_path / "o.jsonl"; save_orders(p, [{"id": 1, "total": 10, "status": "paid"}])
    assert load_orders(p) == [{"id": 1, "total": 10, "status": "paid"}]
def test_old_file_default(tmp_path):
    p = tmp_path / "old.jsonl"; p.write_text('{"id": 7, "total": 70}\n\n{"id": 8, "total": 80}\n')
    assert load_orders(p) == [{"id": 7, "total": 70, "status": "unpaid"}, {"id": 8, "total": 80, "status": "unpaid"}]
def test_save_default(tmp_path):
    p = tmp_path / "o.jsonl"; save_orders(p, [{"id": 2, "total": 5}])
    assert load_orders(p) == [{"id": 2, "total": 5, "status": "unpaid"}]
def test_bad_status(tmp_path):
    import pytest
    with pytest.raises(ValueError): save_orders(tmp_path / "x.jsonl", [{"id": 3, "total": 1, "status": "lost"}])
