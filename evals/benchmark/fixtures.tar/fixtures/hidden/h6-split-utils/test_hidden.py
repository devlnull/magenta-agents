import inspect
def test_new_modules():
    from shop.money import format_rials, parse_rials
    from shop.text import slug, initials
    assert parse_rials("1,500 rials") == 1500 and slug("A b") == "a-b" and initials("ann lee") == "AL"
def test_old_imports_still_work():
    from shop.utils import format_rials, parse_rials, slug, initials
    assert format_rials(2000) == "2,000 rials" and initials("x y") == "XY"
def test_no_duplicate_code():
    import shop.utils as u
    src = inspect.getsource(u)
    assert "def format_rials" not in src and "def slug" not in src
