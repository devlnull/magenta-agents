import csv, io
from shop.users import export_users_csv
def rows(viewer): return list(csv.DictReader(io.StringIO(export_users_csv(viewer))))
def test_columns(): assert set(rows({"role": "admin"})[0]) >= {"id", "name", "email", "phone"}
def test_admin_full():
    r = rows({"role": "admin"}); assert r[0]["email"] == "ann@example.com" and r[0]["phone"] == "09121234567"
def test_masked_email(): assert rows({"role": "support"})[0]["email"] == "a***@example.com"
def test_masked_phone(): assert rows({"role": "support"})[0]["phone"] == "*********67"
def test_short_values(): r = rows({"role": "support"}); assert r[1]["email"] == "c***@x.io" and r[1]["phone"] == "****55"
def test_no_deleted(): assert [x["id"] for x in rows({"role": "admin"})] == ["1", "3"]
