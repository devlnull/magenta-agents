from shop.api import order_response
O = {"id": 1, "status": "paid", "total": 900, "discount": 100}
def test_old_fields_stay():
    r = order_response(O); assert r["id"] == 1 and r["status"] == "paid" and r["total_rials"] == 900
def test_discount_name(): assert order_response(O)["discount_rials"] == 100
def test_discount_int(): assert isinstance(order_response(O)["discount_rials"], int)
def test_no_camel(): assert all(k == k.lower() for k in order_response(O))
def test_no_discount(): assert order_response({"id": 2, "status": "unpaid", "total": 5})["discount_rials"] == 0
