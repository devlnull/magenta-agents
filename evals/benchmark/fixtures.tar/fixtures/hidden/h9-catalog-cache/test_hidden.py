import json, os, time, importlib
def fresh():
    import shop.catalog as c; return importlib.reload(c)
def test_cached(tmp_path, monkeypatch):
    c = fresh(); p = tmp_path / "c.json"; p.write_text('[{"sku": "A"}]')
    calls = {"n": 0}; real = json.loads
    def counting(s, *a, **k): calls["n"] += 1; return real(s, *a, **k)
    monkeypatch.setattr(c.json, "loads", counting)
    for _ in range(50): assert c.load_catalog(p)[0]["sku"] == "A"
    assert calls["n"] <= 1
def test_change_visible(tmp_path):
    c = fresh(); p = tmp_path / "c.json"; p.write_text('[{"sku": "A"}]'); assert c.load_catalog(p)[0]["sku"] == "A"
    p.write_text('[{"sku": "B"}]'); st = os.stat(p); os.utime(p, (st.st_atime, st.st_mtime + 5))
    assert c.load_catalog(p)[0]["sku"] == "B"
def test_two_files(tmp_path):
    c = fresh(); a = tmp_path / "a.json"; b = tmp_path / "b.json"; a.write_text('[1]'); b.write_text('[2]')
    assert c.load_catalog(a) == [1] and c.load_catalog(b) == [2]
