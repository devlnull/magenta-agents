import pytest
from shop.pagination import paginate
ITEMS = list(range(1, 26))
def test_first_page(): assert paginate(ITEMS, 1, 10) == list(range(1, 11))
def test_second_page(): assert paginate(ITEMS, 2, 10) == list(range(11, 21))
def test_last_partial(): assert paginate(ITEMS, 3, 10) == [21, 22, 23, 24, 25]
def test_after_last(): assert paginate(ITEMS, 4, 10) == []
def test_bad_page():
    with pytest.raises(ValueError): paginate(ITEMS, 0, 10)
def test_bad_size():
    with pytest.raises(ValueError): paginate(ITEMS, 1, 0)
def test_empty(): assert paginate([], 1, 10) == []
