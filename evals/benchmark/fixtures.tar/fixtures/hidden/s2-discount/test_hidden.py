import pytest
from shop.pricing import apply_discount
def test_half_up(): assert apply_discount(1005, 15) == 854
def test_exact_half(): assert apply_discount(10, 5) == 9   # 0.5 -> 1
def test_below_half(): assert apply_discount(1001, 10) == 901   # 100.1 -> 100
def test_zero(): assert apply_discount(1000, 0) == 1000
def test_full(): assert apply_discount(999, 100) == 0
def test_negative_percent():
    with pytest.raises(ValueError): apply_discount(1000, -1)
def test_over_100():
    with pytest.raises(ValueError): apply_discount(1000, 101)
def test_type_int(): assert isinstance(apply_discount(1005, 15), int)
