from shop.text import slugify
def test_old_behavior(): assert slugify("Hello  World!") == "hello-world"
def test_no_limit(): assert slugify("a b c") == "a-b-c"
def test_cut_at_word(): assert slugify("Hello big world", max_length=10) == "hello-big"
def test_exact(): assert slugify("hello world", max_length=11) == "hello-world"
def test_no_trailing_dash(): assert not slugify("hello world again", max_length=12).endswith("-")
def test_first_word_too_long(): assert slugify("supercalifragilistic word", max_length=5) == "super"
def test_result_within_limit():
    for n in range(1, 30):
        assert len(slugify("the quick brown fox jumps over", max_length=n)) <= n
