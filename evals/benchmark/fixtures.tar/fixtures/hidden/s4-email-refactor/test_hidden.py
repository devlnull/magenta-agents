import pytest, inspect
from shop import users, newsletter
import shop.validation as validation
def test_function_exists(): assert callable(validation.validate_email)
def test_register_strips_and_lowers(): assert users.register("  Ann@Example.COM ") == {"email": "ann@example.com"}
def test_register_rejects():
    with pytest.raises(ValueError): users.register("no-at.example.com")
def test_subscribe_keeps_case(): assert newsletter.subscribe("Ann@Example.COM") == {"email": "Ann@Example.COM"}
def test_subscribe_no_strip():
    with pytest.raises(ValueError): newsletter.subscribe(" ann@example.com")
def test_subscribe_rejects():
    with pytest.raises(ValueError): newsletter.subscribe("ann@example")
def test_one_regex():
    src = inspect.getsource(users) + inspect.getsource(newsletter)
    assert "fullmatch" not in src and "re.match" not in src
