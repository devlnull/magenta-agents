def paginate(items, page, size):
    """Return the items of one page. `page` starts at 1. Raise ValueError when page < 1 or size < 1.
    A page after the last page is empty."""
    start = page * size
    return items[start:start + size]
