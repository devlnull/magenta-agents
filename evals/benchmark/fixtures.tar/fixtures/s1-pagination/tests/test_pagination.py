from shop.pagination import paginate

def test_empty_list():
    assert paginate([], 1, 10) == []
