def apply_discount(price, percent):
    """Price after a percentage discount, in whole rials. The discount amount is rounded half up
    (15% of 1005 = 150.75 -> 151, so the result is 854). `percent` is from 0 to 100; else ValueError."""
    discount = price * percent // 100
    return price - discount
