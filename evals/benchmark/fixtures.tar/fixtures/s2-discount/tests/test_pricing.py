from shop.pricing import apply_discount

def test_no_discount():
    assert apply_discount(1000, 0) == 1000
