import re

def slugify(text):
    """Lower case, words joined by '-', only a-z and 0-9."""
    words = re.findall(r"[a-z0-9]+", text.lower())
    return "-".join(words)
