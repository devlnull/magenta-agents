import re

def subscribe(email):
    """Subscribe an email to the newsletter. The email is kept as given (no strip, no lower case),
    and the top-level domain can have upper-case letters."""
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}", email):
        raise ValueError("invalid email")
    return {"email": email}
