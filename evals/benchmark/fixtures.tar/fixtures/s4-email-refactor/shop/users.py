import re

def register(email):
    """Register a user. The email is stripped and lower-cased."""
    email = email.strip().lower()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", email):
        raise ValueError("invalid email")
    return {"email": email}
