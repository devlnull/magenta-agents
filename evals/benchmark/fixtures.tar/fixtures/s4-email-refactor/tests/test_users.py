from shop.users import register

def test_register():
    assert register("A@B.com") == {"email": "a@b.com"}
